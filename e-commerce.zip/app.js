const express = require('express');
const app = express();
const seedDB = require('./seed'); // Importing a seed function (commented out)
const path = require('path');
const mongoose = require('mongoose');
const ejsmate = require('ejs-mate')
const methodOverride = require('method-override');
const flash = require('connect-flash');
const session = require('express-session');
const User = require('./models/User');
const LocalStrategy = require('passport-local');
const passport = require('passport')




const productroutes = require('./routes/product');
const reviewroutes = require('./routes/review');
const userroutes = require('./routes/user')
const cartroutes=require('./routes/cart')

// MongoDB connection


mongoose.connect('mongodb://127.0.0.1:27017/mycars')
  .then(() => {
    console.log("db connected");
  })
  .catch(() => {
    console.log("db error");
  });






  // Session configuration
//app.set('trust proxy', 1); // trust first proxy
let configSession = {
  secret: 'keyboard cat',
  resave: false,
  saveUninitialized: true,
  cookie: { 
    httpOnly:true,
    expires:Date.now()+7*24*60*60*1000,
    maxAge:7*24*60*60*1000,
   } // Uncomment in production for secure cookies over HTTPS
}



// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
// Middleware setup
// Static files setup
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true })); // Body parser middleware
app.use(methodOverride('_method')); // Method override middleware
app.engine('ejs', ejsmate);
app.use(flash()); // Flash messages middleware
app.use(session(configSession)); // Session middleware
// Passport setup
app.use(passport.initialize());
app.use(passport.session());
// Passport local strategy setup
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());




// Custom middleware to add local and flash messages to the response object

app.use((req, res, next) => {
  res.locals.currentUser=req.user;
  res.locals.success = req.flash('success')
  res.locals.error = req.flash('error');
  next();
})





//passport wala
passport.use(new LocalStrategy(User.authenticate()));


// Routes setup
app.use(productroutes);
app.use(reviewroutes);
app.use(userroutes);
app.use(cartroutes);





const port = 8080;

// Server start
app.listen(port, () => {
  console.log(`server is running at ${port}`);
});
